namespace Common
{
    public class TabulationQuery : BasisRequest
    {

        public string TabulationOrdinal { get; set; }//
    }
}