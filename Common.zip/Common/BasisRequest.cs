namespace Common
{
    public class BasisRequest
    {
        public CountyCode CountyCode { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}