﻿namespace Common
{
    public enum Gender { Male, Female,Unknown }
}