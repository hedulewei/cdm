﻿namespace Common
{
    public enum BusinessStatus {AutoSubmit, Upload, PartUpload, Processing, Reject, Fee,Discard,Paid,License }
}