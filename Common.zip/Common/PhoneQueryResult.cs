namespace Common
{
    public class PhoneQueryResult : CommonResult
    {
        public string PhoneNumber { get; set; }//
        public string Address { get; set; }//
        public string Name { get; set; }//
    }
}