﻿namespace Common
{
    public enum VoiceType { Fee, Reject ,PlayOver}
}