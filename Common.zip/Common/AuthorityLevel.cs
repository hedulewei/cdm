﻿namespace Common
{
    public enum AuthorityLevel { Ordinary, CountyMagistrate, Administrator }
}