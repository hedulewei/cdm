namespace Common
{
    public class IndentityInforQuery : CommonRequest
    {
        public string IdentityCardNumber { get; set; }//
        public string PhoneNumber { get; set; }//
        public Gender Gender { get; set; }//
        public string Nationality { get; set; }//
        public string Birthday { get; set; }//
        public string Address { get; set; }//
        public string Name { get; set; }//
    }
}