﻿namespace Common
{
    public enum CountyCode
    {
        HaiYang, FuShan, QiXia, LaiShan, ZhiFu,
        MuPing, LongKou, LaiYang, LaiZhou, PengLai,
        ZhaoYuan, ChangDao,
        DaCheng,ShiSuo
    }
}