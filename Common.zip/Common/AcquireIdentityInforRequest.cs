namespace Common
{
    public class AcquireIdentityInforRequest : BasisRequest
    {
        public string IdentityCardNumber { get; set; }//
       
    }
}