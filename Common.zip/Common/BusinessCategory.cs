﻿namespace Common
{
    public enum BusinessCategory { Cars, Drivers,Archives }
}