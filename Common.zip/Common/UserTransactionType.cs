namespace Common
{
    public enum UserTransactionType { Add, Update, GetUserList, Disable,ResetPass ,Login,ChangePass}
}