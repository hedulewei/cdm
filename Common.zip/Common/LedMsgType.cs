﻿namespace Common
{
    public enum LedMsgType { Processing, Reject ,Done}
}