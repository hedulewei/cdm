﻿namespace Common
{
    public enum ClientType { Voice, Led }
}