namespace Common
{
    public class VoiceCallRequest : CommonRequest
    {

        public string VoiceContent { get; set; }//
    }
}