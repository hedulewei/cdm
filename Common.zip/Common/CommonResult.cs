namespace Common
{
    public class CommonResult
    {
        public string StatusCode { get; set; }
        public string Result { get; set; }
    }
}