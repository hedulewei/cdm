﻿namespace Common
{
    public enum UserRole { Audit, Accept, Pay, Certificate }
}