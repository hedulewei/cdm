namespace Common
{
    public class DahcUser
    {
        public string UserName { get; set; }
        public int Id { get; set; }//
    }
}