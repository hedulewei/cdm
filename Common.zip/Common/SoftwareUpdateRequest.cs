namespace Common
{
    public class SoftwareUpdateRequest : BasisRequest
    {
      
        public string Version { get; set; }// like 3.45 , 6.789 etc
    }
}